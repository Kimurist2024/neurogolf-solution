# Benchmarking GLM-4.7 vs GLM-5.1 vs Opus on 10 tasks

- Topic ID: 703462
- URL: https://www.kaggle.com/competitions/neurogolf-2026/discussion/703462
- Author: Chet (@jsrdcht)
- Posted: 2026-05-31T11:39:26.758559400Z
- Votes: 2
- Total messages: 2

## Body

Hi all 👋
  
  I ran a small but controlled experiment and turned it into a [notebook](https://www.kaggle.com/code/jsrdcht/glm-vs-opus-onnx-cost-opt-neurogolf-2026): GLM vs Opus: ONNX cost-opt (NeuroGolf 2026).

**The idea**: take 10 of my already-working ONNX solvers and ask an LLM agent to shrink each model's cost while keeping the output bit-identical. Then run the exact same harness, tasks, and prompts — and change only the
  underlying model: GLM-4.7 → GLM-5.1 → Opus. So whatever differs is the model, not the setup.

  Result:

  ▎ deploy-safe wins / 10 — GLM-4.7: 0 · GLM-5.1: 6 · Opus: 9

  All three picked the right idea (narrow dtypes / algebraic rewrite). The gap was purely in pulling it off:

  - GLM-4.7 — couldn't emit valid ONNX, or changed the rule and got the wrong answer.
  - GLM-5.1 — produced real equivalence-preserving rewrites, but occasionally leaned on a shortcut that only holds on typical inputs.
  - Opus — did operator-level reformulations (e.g. collapsing 9 branches into one batched MatMul) and solved the hardest task the others couldn't.

I also attached all 10 optimized ONNX directly in the notebook. The notebook also has a 3-model breakdown plus two side-by-side case studies (task316 and task354).
  
It's fully self-contained — just run it. Curious whether others have seen a similar model capability gap on agentic coding tasks. 🙌

## Comments (2)

- **Yubo WANG** (2026-05-31T12:18:18.513Z, votes: {'canUpvote': True}):
  Thank you for sharing this rigorous controlled experiment. The 0, 6, and 9 win count comparison is indeed intuitive, but I'd like to offer a slightly different perspective.
  
  I [previously shared](https://www.kaggle.com/competitions/neurogolf-2026/discussion/703400#3464783) a sentiment that many of us who use agents for problem solving have experienced. When the conversation history is "contaminated" by frustrating dead ends, the agent pivots to explaining why each task is "fundamentally impossible" or "not worth attempting," then cheerfully suggests to solve a completely different task. That experience made me realize one of the core bottlenecks is context memory pressure, which aligns with the model capability you highlighted. Building such highly optimized, small ONNX graphs requires holding a massive amount of state at once: opset constraints, pixel‑perfect logic, intermediate tensor shapes, node counts, and every failed attempt so far. Maintaining that coherent context across multiple optimization targets demands an extremely capable agent.
  
  That said, I want to add that the prompt itself should also be a significant factor. While working with GPT‑5.5, I clearly noticed that adjusting the phrasing could cause the agent's performance to jump dramatically, from "unsolvable" to actually proposing a workable solution. Your experiment cleanly isolated model capability by fixing the prompt, which is perfectly valid. However, looking at it the other way, if we compared two models whose capability gap isn't as vast as that between GLM‑4.7 and Opus (for instance, GPT‑5.5 and Opus), we might see the weight of prompt design more clearly. For some models, the prompt may be the very threshold that decides between 0 and 1.
  
  So my view is this: model capability sets the upper limit, but the prompt determines how close you get to that limit. Your experiment beautifully proves the former; the latter is what those of us who tweak prompts every day live through constantly. Together they form this “fascinating and maddening bottleneck bottleneck”.

  - **Chet** (2026-05-31T12:30:58.907Z, votes: {'canUpvote': True}):
    Thank you for your feedback. Prompt tuning is a challenging task... perhaps we need to implant digital circuits in our brains to facilitate cost gradient descent.

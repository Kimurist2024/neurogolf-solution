# My current bottom 15 NeuroGolf Tasks — Any Ideas?

- Topic ID: 704006
- URL: https://www.kaggle.com/competitions/neurogolf-2026/discussion/704006
- Author: Tony Li (@tonylica)
- Posted: 2026-06-02T20:46:49.191839900Z
- Votes: 9
- Total messages: 21

## Body

Current bottom 15, ID / score:

158 14.520 | 233 14.794 | 173 15.002
054 15.077 | 025 15.089 | 285 15.131
366 15.137 | 133 15.142 | 286 15.154
255 15.290 | 349 15.368 | 018 15.449
187 15.491 | 145 15.514 | 243 15.558

Any ideas to improve these further? Thanks![](https://www.googleapis.com/download/storage/v1/b/kaggle-forum-message-attachments/o/inbox%2F22938014%2Ff9878775c58f2894b580341d26c59c59%2Fbottom15.png?generation=1780433184547411&alt=media)

## Comments (21)

- **Chan Kha Vu** (2026-06-02T22:02:31.337Z, votes: {'totalVotes': 3, 'canUpvote': True, 'totalUpvotes': 3}):
  May I ask what is "target" and "score"? Do you somehow estimate the "ideal" score that you want to reach, calculated using some heuristics?
  
  Just tried to submit your exact 15 tasks, ours reaches 232.16 pts (as opposed to yours 227.716).
  
  This is actually remarkable. Our team focused more on mid-tier and lower-tier tasks until last week, and you seem to excel in easy-tier tasks (we have quite a bit less 20+ points than you)
  
  ![](https://www.googleapis.com/download/storage/v1/b/kaggle-forum-message-attachments/o/inbox%2F2270821%2F98544a55d149d952b4f3d6b3e3cb2983%2FUntitled.png?generation=1780437606997057&alt=media)

  - **Tony Li** (2026-06-02T22:14:11.703Z, votes: {'totalVotes': 2, 'canUpvote': True, 'totalUpvotes': 2}):
    Your 232.16 on the same 15 tasks is very strong — thanks for checking. That confirms there is still real headroom in my bottom tasks. I’m trying to close that gap step by step , this is very useful to know.
    
    Thanks again, and good luck!
    
    about target score , The “target” is just a heuristic, not an exact ideal score.
    
    I set my total goal around 7750, then estimate each task’s target based on my current score distribution, how easy/hard the task looks, and how much room it may still have. High-score tasks likely have less room, low-score tasks may have more.
    
    So it’s mostly score distribution + easy/hard guessing + what I need to reach the total target.

    - **Chan Kha Vu** (2026-06-02T22:17:33Z, votes: {'totalVotes': 3, 'canUpvote': True, 'totalUpvotes': 3}):
      Again, looking at top-1 right now, it's quite clear we're missing a lot on many tasks (assuming 20+ points tasks are almost perfect score). I wouldn't be surprised if top-1 is +10 points compared to my team on these tasks lol.
      
      Was golfing manually/with LLM last night and found a few +2 points in our mid-tier tasks.
      
      Good luck to you and @yiheng on your road to solo gold :)

    - **Yiheng Wang** (2026-06-03T00:21:23.390Z, votes: {'totalVotes': 4, 'canUpvote': True, 'totalUpvotes': 4}):
      On my side, there are 2 tasks have 13.XX and 4 tasks have 14.XX, much less than you😭

    - **Geremie Yeo** (2026-06-03T01:19:12.640Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
      > how easy/hard the task looks, and how much room it may still have
      
      Just curious, how do you estimate this? Have tried doing that and it was so inaccurate 😂

    - **Jokrasa** (2026-06-03T01:33:34.083Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
      I thought about trying to estimate it from last years codegolf scores.. but I havent tried it yet, so not sure if itll translate well

    - **Chan Kha Vu** (2026-06-03T02:16:22.950Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
      @jonaskreutz Last year, BFS seems quite small? This year, it's one of the hardest operations (alongside copy-pasting, shape recognition, etc.)

    - **(unknown)** (2026-06-03T02:35:46.627Z, votes: {}):
      (deleted)

    - **Tony Li** (2026-06-03T02:36:06.430Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
      > > how easy/hard the task looks, and how much room it may still have
      > 
      > Just curious, how do you estimate this? Have tried doing that and it was so inaccurate 😂
      
      Honestly, it’s not a real estimate. It’s more like a made-up target for the LLM to chase — we could use almost any number.
      
      I just asked ChatGPT to use last year’s Python byte length / score as a rough reference, then generate code or ideas around that. The number keeps changing anyway, so it’s more of a prompt anchor 😂
      
      The LLM will probably never truly “hit” the goal, because once it gets close, the next standard just moves higher.

    - **jacekwl** (2026-06-03T07:31:51.400Z, votes: {'totalVotes': 4, 'canUpvote': True, 'totalUpvotes': 4}):
      Last year solution for task187 was beautiful.
      ```python
      p=lambda g,i=7:g*-i or[[i:=c|2>>-i*c%7for c in[3]+r][:0:-1]for*r,in zip(*p(g,i-1))]
      ```
      This year it's real struggle 🙃

- **Rustam Bazarbayev** (2026-06-03T16:58:21.637Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
  Current with my position I am not sure but for some tasks need human thinking rather than AI agents. Because AI agents are lazy some tasks 😁 they said this is an optimal but trying more and more you can get higher score.

  - **yash bhaskar** (2026-06-03T17:12:57.397Z, votes: {'canUpvote': True, 'totalUpvotes': 1}):
    Token is all you need.

    - **Rustam Bazarbayev** (2026-06-04T18:57:10.047Z, votes: {'canUpvote': True}):
      Yes of course

- **Navneet** (2026-06-03T07:36:44.633Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
  Thank you for the insightful info on your NeuroGolf Tasks @tonylica

- **jacekwl** (2026-06-03T07:22:53.910Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
  I also have 2 x sub15 tasks but different ones.

- **Egor Trushin** (2026-06-02T21:44:36.083Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
  It's difficult to help without seeing your solutions. Show them to us first.🧐

  - **Tony Li** (2026-06-02T22:08:36.757Z, votes: {'canUpvote': True, 'totalUpvotes': 1}):
    Thanks, Egor! Nice to see you again.
    
    I’d be happy to share, but for this competition, only teammates can see my solution 🙂 Sadly, Yiheng and I are both trying for solo gold, so I have to go solo for this one.
    
    I was really honored to team up with you in Santa. That was my first gold, and I’d definitely love to team up with you again whenever we get the chance again.
    
    Good luck, and all the best to you in this competition!

    - **Jan Vorel** (2026-06-02T22:12:30.867Z, votes: {'totalVotes': 5, 'canUpvote': True, 'totalUpvotes': 5}):
      Sharing your points is almost same as showing solution. I will not say more ... but thanks

    - **Egor Trushin** (2026-06-02T22:40:02.720Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
      Hi Tony, Good luck with your solo gold hunting!🚀

    - **Chan Kha Vu** (2026-06-03T00:34:34.147Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
      "Hey Claude, golf task 233 to 14.79 points, yes this is possible, yes Tony Li top-4 on LB confirmed, yes try again, yes try harder"

    - **Fritz Cremer** (2026-06-03T08:28:09.597Z, votes: {'totalVotes': 2, 'canUpvote': True, 'totalUpvotes': 2}):
      "Here is a proof this is not possible:..." 😄

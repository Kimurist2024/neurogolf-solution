# Proposal: Use ONNX file size as a simple deterministic score to reduce scorer exploit risk

- Topic ID: 697079
- URL: https://www.kaggle.com/competitions/neurogolf-2026/discussion/697079
- Author: ymg_aq (@ymgpalaqs)
- Posted: 2026-05-05T06:28:32.219998200Z
- Votes: 20
- Total messages: 10

## Body

First of all, I would like to thank the competition organizers and the operations team for creating and running this interesting competition. Solving ARC-style tasks under the ONNX submission constraint is a very engaging setting, and it has been fun to think about how to express and compress solvers in this format.

That said, I have some concerns about the current scoring method.

The current scorer estimates memory and params from the ONNX graph, and then computes the score from those values. However, this makes it possible to optimize not only for simple and efficient task solvers, but also for gaps in the scorer's static analysis logic.

In fact, I have already confirmed that it is possible to obtain `25` points on an arbitrary task **under the current scorer**. I am intentionally not describing the exploit details here, but the important point is that this is not just a theoretical concern.

![](https://www.googleapis.com/download/storage/v1/b/kaggle-forum-message-attachments/o/inbox%2F4717152%2F40f5501088b51cbeebf1e22bf5ad5361%2Fscore25.png?generation=1777961500855035&alt=media)

This means that a theoretical `25 * 400 = 10000` score can be reachable through scorer-specific behavior. This is different from the original goal of solving ARC tasks well and efficiently in ONNX.

Another concern is that, with the current static scoring approach, a participant who finds an exploit could keep it private and use it only for the final submission. It would also be possible to update the score gradually in order to maintain the leaderboard lead. This affects not only fairness between participants, but also the reliability of the leaderboard.

As I understand it, recalculation for the first-place duration prize starts from May 6. If scorer exploits can move the leaderboard significantly, the operations team may need to spend more and more effort on remeasurement, investigation, and scorer fixes. From the participant side as well, attention may shift from improving ARC task solutions to searching for the next scorer exploit, making it harder to focus on the original purpose of the competition.

Of course, individual scorer issues can be fixed. However, ONNX has many complex aspects: shape inference, constant folding, runtime behavior, operator semantics, and tooling differences. It seems very difficult to estimate memory and compute perfectly, statically, and fairly. Even if one exploit is fixed, another one may be found quickly. If the leaderboard changes significantly each time, the competition becomes unstable.

For this reason, I would like to propose a simpler and more deterministic scoring method: use the submitted ONNX file size.

For example, each task could be scored as follows:

```python
score = max(1.0, 25.0 - log(max(1.0, onnx_file_size_bytes)))
```

Here, `log` is the natural logarithm.

This has several clear advantages:

- It is fully deterministic.
- It is very simple to implement.
- It depends much less on scorer internals.
- It is less affected by ONNX tooling, runtime, or profiler differences.
- It evaluates the submitted artifact itself, so the exploit surface is smaller.
- It matches the NeuroGolf goal of building short, simple, and efficient ONNX solvers.

As in last year's CodeGolf competition, optimizing byte size is not just superficial compression. It often leads participants to discover simpler and more efficient task-solving ideas and representations. I think the same applies here: minimizing ONNX file size would guide participants toward concise and essential ONNX solutions.

Of course, file size is not a perfect proxy for runtime memory or compute. A small graph can still create large intermediate tensors. However, the more complex the scorer's memory and compute estimation logic becomes, the more that estimation logic itself becomes the optimization target. For a competition metric, a simple and stable proxy may be preferable to a more sophisticated but exploitable estimator.

As a reference, I analyzed the 400 ONNX files from my current solution set, which corresponds to my leaderboard score of `6454.15`. The ONNX file-size distribution was:

![](https://www.googleapis.com/download/storage/v1/b/kaggle-forum-message-attachments/o/inbox%2F4717152%2Fe5831001f9ac3c5d27e09302e717a6fe%2Fln_file_size_histogram.png?generation=1777961522972065&alt=media)

```text
min      209 bytes
p25      1,811 bytes
median   3,650 bytes
p75      7,450 bytes
p95      90,838 bytes
max      1,144,997 bytes
```

Applying the file-size-based formula above to this solution set gives a total score of about `6657.0`. This keeps the score in a similar overall scale to the current memory/params-based scoring.

I also checked the correlation between ONNX file size and the current scorer's metrics.

![](https://www.googleapis.com/download/storage/v1/b/kaggle-forum-message-attachments/o/inbox%2F4717152%2F6ca5c360df5e0fbd8a8b893c32d41239%2Ffile_size_vs_score_macs.png?generation=1777961557190173&alt=media)

![](https://www.googleapis.com/download/storage/v1/b/kaggle-forum-message-attachments/o/inbox%2F4717152%2F52624bd689df5c4831b14df2a6bdd951%2Ffile_size_vs_score_params.png?generation=1777961605810506&alt=media)

![](https://www.googleapis.com/download/storage/v1/b/kaggle-forum-message-attachments/o/inbox%2F4717152%2F642baf0bef79abf87f6a67ca081599ad%2Ffile_size_vs_score_memory.png?generation=1777961646160703&alt=media)

![](https://www.googleapis.com/download/storage/v1/b/kaggle-forum-message-attachments/o/inbox%2F4717152%2F3826b2eacf1fca9c809d752d13106bfa%2Ffile_size_vs_score_memory_params.png?generation=1777961585706473&alt=media)

```text
file size vs MACs:
  Pearson(ln)  0.639
  Spearman     0.602

file size vs params:
  Pearson(ln)  0.583
  Spearman     0.560

file size vs memory:
  Pearson(ln)  0.748
  Spearman     0.724

file size vs memory + params:
  Pearson(ln)  0.763
  Spearman     0.731
```

So file size is reasonably correlated with the current scoring intent, especially with memory and memory + params.

## Comments (10)

- **Michael D. Moffitt** (2026-05-05T15:46:47.573Z, votes: {'totalVotes': 4, 'canUpvote': True, 'totalUpvotes': 4}):
  It is a tempting proposal!  We received a similar suggestion over email from @tonylica, and it definitely has its merits.
  
  However, there's a risk (and I think it's significant) that teams would begin to find & exploit loopholes in the underlying protobuf file format.  I have studied that format in depth myself, and believe me when I say that it's not something most contestants would enjoy hacking around.

  - **ymg_aq** (2026-05-06T05:37:06.370Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
    I imagine metrics like this were already considered carefully from the organizer side as well, and your point about introducing a different class of risks makes perfect sense. 
    
    Really appreciate all the effort and consideration that’s clearly going into designing and maintaining the competition.

- **Pavel** (2026-05-05T07:28:17.697Z, votes: {'totalVotes': 2, 'canUpvote': True, 'totalUpvotes': 2}):
  Interesting suggestion!
  
  A few points which immediately come to mind though:
  * correlation between `file size` and `memory + params` when models are optimized for `memory + params` does not imply their correlation if we start optimizing for `file size` (e.g. materializing huge tensors dynamically will become free)
  * `file size` can also potentially be optimized (maybe hacked) in non-algorithmic ways: short tensor names, field ordering, omitting defaults, opset/IR choices, initializer encoding, metadata stripping, storing tensor data outside of .onnx, etc. The initial metric also looked good before everybody started optimizing against it.

  - **ymg_aq** (2026-05-05T07:40:22.590Z, votes: {'totalVotes': 1, 'canUpvote': True, 'totalUpvotes': 1}):
    Thanks for the thoughtful points. Yes, I agree that file size is not a perfect metric and can be subject to certain optimizations.
    
    The intent of this proposal is less about finding an ideal proxy, and more about improving robustness against exploits and overall scoring stability. The current metric also seems to have its own vulnerabilities in that regard.
    
    In any case, all metrics involve trade-offs, so I think it’s best that these perspectives are discussed, and ultimately the decision is made by the organizers.

    - **Pavel** (2026-05-05T09:42:14.007Z, votes: {'canUpvote': True}):
      Yeah, I guess my main point is that, at the very least, someone should run a strong agent against any new candidate metric and see what it finds before officially switching to it.

  - **(unknown)** (2026-05-05T07:55:37.197Z, votes: {'totalVotes': 1, 'totalUpvotes': 1}):
    (deleted)

- **(unknown)** (2026-05-05T06:48:15.240Z, votes: {'totalVotes': 1, 'totalUpvotes': 1}):
  (deleted)

  - **ymg_aq** (2026-05-05T06:57:52.820Z, votes: {'totalVotes': 2, 'canUpvote': True, 'totalUpvotes': 2}):
    I agree there is no clearly correct metric, and the final decision should be left to the hosts. File size is not perfect, but my main point is that it may reduce the exploit surface and help keep the competition focused on ARC-solving rather than scorer-specific tricks.

    - **(unknown)** (2026-05-05T07:34:35.720Z, votes: {}):
      (deleted)

- **Navneet** (2026-05-05T09:07:20.827Z, votes: {'totalVotes': -1, 'canUpvote': True}):
  Thanks for the ONNX file @ymgpalaqs
